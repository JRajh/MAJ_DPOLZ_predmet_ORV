﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.Util;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Emgu.CV.CvEnum;
using System.Configuration;
using System.Data.SqlClient;

namespace ORV_StreznikApp
{
    public partial class Form1 : Form
    {
        // database
        string connectionString;
        SqlConnection connection;
        SqlDataAdapter adapter;
        SqlCommand command;
        DataTable dTable;

        // image variables
        Image<Bgr, byte> My_ImageRecieve;

        int[] vrednosti_pixlov = new int[256];
        int[] vrednost_pixlov_uniformni = new int[59];
        Image<Gray, byte> imgSiva;
        Image<Gray, byte> lbn;



        public Form1()
        {
            InitializeComponent();
            // initialize connectionString to Database
            connectionString = ConfigurationManager.ConnectionStrings["ORV_StreznikApp.Properties.Settings.ORV_StreznikDatabaseConnectionString"].ConnectionString;
            connectMe();
        }
        /*
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        */
        private void button1_Click(object sender, EventArgs e)
        {
            // initialize Form2 to upload
            Form2 newF = new Form2();
            if(newF.ShowDialog() == DialogResult.OK)
            {
                // GET IMAGE
                My_ImageRecieve = new Image<Bgr, byte>(newF.MyImageSG.ToBitmap());
                pictureBox1.Image = My_ImageRecieve.ToBitmap();
                
            }
        }

        private void connectMe()
        {
            using (connection = new SqlConnection(connectionString))
            using (adapter = new SqlDataAdapter("SELECT * FROM ImageT", connection))
            {
                dTable = new DataTable();
                adapter.Fill(dTable);

                listBox1.DisplayMember = "imageDescriptives";
                listBox1.ValueMember = "Id";
                listBox1.DataSource = dTable;
            }
        }

        private void insertMe()
        {
            // initialize Database: query,
            string query = "INSERT INTO ImageT VALUES(@imgDesc)";
            // SAVE IMAGE DESCRIPTIVES TO DATABASE
            /*sectionStart*/
            using (connection = new SqlConnection(connectionString))
            using (command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@imgDesc", IntArrayToString(vrednosti_pixlov));
                command.ExecuteNonQuery();
                connectMe();
            }
            /*sectionEnd*/
            /*TODO*/
        }

        public string IntArrayToString(int[] ints)
        {
            return string.Join(",", ints.Select(x => x.ToString()).ToArray());
        }// end of IntArrayToString

        private void LBPbasic()
        {
            int i;
            int j;
            int x;
            int y;
            int[,] maska = new int[3, 3];

            int[,] maska_primerjava = new int[3, 3];

            //int[] vrednosti_pixlov = new int[256];

            string bin_vrednost;
            int bin_v_int;

            imgSiva = My_ImageRecieve.Convert<Gray, Byte>();

            Image<Gray, byte> lbn = new Image<Gray, byte>(imgSiva.Width, imgSiva.Height);
            //gremo čez vse piksle slike
            for (i = 0; i < imgSiva.Height; i++)
            {
                for (j = 0; j < imgSiva.Width; j++)
                {

                    //dodajanje vrednosti v masko
                    for (x = 0; x < 3; x++)
                    {
                        for (y = 0; y < 3; y++)
                        {
                            //maska[0,0]
                            if (x == 0 && y == 0 && (i - 1 < 0 || j - 1 < 0))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i - 1, j - 1, 0];
                            }
                            //maska[0,1]
                            if (x == 0 && y == 1 && i - 1 < 0)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 1)
                            {

                                maska[x, y] = (int)imgSiva.Data[i - 1, j, 0];
                            }
                            //maska[0,2]
                            if (x == 0 && y == 2 && (i - 1 < 0 || j + 1 >= imgSiva.Width))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i - 1, j + 1, 0];
                            }
                            //maska[1,0]
                            if (x == 1 && y == 0 && j - 1 < 0)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 1 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j - 1, 0];
                            }
                            //maska[1,1]
                            if (x == 1 && y == 1)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j, 0];
                            }
                            //maska[1,2]
                            if (x == 1 && y == 2 && j + 1 >= imgSiva.Width)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 1 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j + 1, 0];
                            }
                            //maska[2,0]
                            if (x == 2 && y == 0 && (i + 1 >= imgSiva.Height || j - 1 < 0))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j - 1, 0];
                            }
                            //maska[2,1]
                            if (x == 2 && y == 1 && i + 1 >= imgSiva.Height)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 1)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j, 0];
                            }

                            //maska[2,2]
                            if (x == 2 && y == 2 && (i + 1 >= imgSiva.Height || j + 1 >= imgSiva.Width))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j + 1, 0];
                            }

                        }
                    }

                    // primerjanje vrednosti v maski
                    for (x = 0; x < 3; x++)
                    {
                        for (y = 0; y < 3; y++)
                        {
                            //če je vrednost soseda manjša 
                            if (maska[x, y] <= maska[1, 1])
                            {
                                maska_primerjava[x, y] = 1;
                            }
                            //če je vrednost soseda večja ali enaka 
                            else if (maska[x, y] > maska[1, 1])
                            {
                                maska_primerjava[x, y] = 0;
                            }

                        }
                    }
                    //pretvorba v binarno stivilo
                    //zacnemo z sosedom na poziciji maska[0,0] in nadaljujemo v smeri urinega kazalca po maski
                    bin_vrednost = maska_primerjava[0, 0].ToString() + maska_primerjava[0, 1].ToString() + maska_primerjava[0, 2].ToString() + maska_primerjava[1, 2].ToString() + maska_primerjava[2, 2].ToString() + maska_primerjava[2, 1].ToString() + maska_primerjava[2, 0].ToString() + maska_primerjava[1, 0].ToString();

                    //polje pojavitve vrednosti
                    bin_v_int = Convert.ToInt32(bin_vrednost, 2);
                    //vnesemo klko krat se kera vrednost pojavi
                    vrednosti_pixlov[bin_v_int]++;
                    //nastavimo vrednost piksla v novi sliki
                    lbn.Data[i, j, 0] = (byte)bin_v_int;

                }
            }
            pictureBox2.Image = lbn.ToBitmap();
        }// end of LBPbasic

        private void LBPuniform()
        {
            int i;
            int j;
            int x;
            int y;
            int[,] maska = new int[3, 3];

            int[,] maska_primerjava = new int[3, 3];

            //int[] vrednosti_pixlov = new int[256];

            string bin_vrednost;
            int bin_v_int;

            imgSiva = My_ImageRecieve.Convert<Gray, Byte>();

            Image<Gray, byte> lbn = new Image<Gray, byte>(imgSiva.Width, imgSiva.Height);
            //gremo čez vse piksle slike
            for (i = 0; i < imgSiva.Height; i++)
            {
                for (j = 0; j < imgSiva.Width; j++)
                {

                    //dodajanje vrednosti v masko
                    for (x = 0; x < 3; x++)
                    {
                        for (y = 0; y < 3; y++)
                        {
                            //maska[0,0]
                            if (x == 0 && y == 0 && (i - 1 < 0 || j - 1 < 0))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i - 1, j - 1, 0];
                            }
                            //maska[0,1]
                            if (x == 0 && y == 1 && i - 1 < 0)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 1)
                            {

                                maska[x, y] = (int)imgSiva.Data[i - 1, j, 0];
                            }
                            //maska[0,2]
                            if (x == 0 && y == 2 && (i - 1 < 0 || j + 1 >= imgSiva.Width))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i - 1, j + 1, 0];
                            }
                            //maska[1,0]
                            if (x == 1 && y == 0 && j - 1 < 0)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 1 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j - 1, 0];
                            }
                            //maska[1,1]
                            if (x == 1 && y == 1)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j, 0];
                            }
                            //maska[1,2]
                            if (x == 1 && y == 2 && j + 1 >= imgSiva.Width)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 1 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j + 1, 0];
                            }
                            //maska[2,0]
                            if (x == 2 && y == 0 && (i + 1 >= imgSiva.Height || j - 1 < 0))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j - 1, 0];
                            }
                            //maska[2,1]
                            if (x == 2 && y == 1 && i + 1 >= imgSiva.Height)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 1)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j, 0];
                            }

                            //maska[2,2]
                            if (x == 2 && y == 2 && (i + 1 >= imgSiva.Height || j + 1 >= imgSiva.Width))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j + 1, 0];
                            }

                        }
                    }

                    // primerjanje vrednosti v maski
                    for (x = 0; x < 3; x++)
                    {
                        for (y = 0; y < 3; y++)
                        {
                            //če je vrednost soseda manjša 
                            if (maska[x, y] <= maska[1, 1])
                            {
                                maska_primerjava[x, y] = 1;
                            }
                            //če je vrednost soseda večja ali enaka 
                            else if (maska[x, y] > maska[1, 1])
                            {
                                maska_primerjava[x, y] = 0;
                            }

                        }
                    }
                    //pretvorba v binarno stivilo
                    //zacnemo z sosedom na poziciji maska[0,0] in nadaljujemo v smeri urinega kazalca po maski
                    bin_vrednost = maska_primerjava[0, 0].ToString() + maska_primerjava[0, 1].ToString() + maska_primerjava[0, 2].ToString() + maska_primerjava[1, 2].ToString() + maska_primerjava[2, 2].ToString() + maska_primerjava[2, 1].ToString() + maska_primerjava[2, 0].ToString() + maska_primerjava[1, 0].ToString();

                    //polje pojavitve vrednosti
                    bin_v_int = Convert.ToInt32(bin_vrednost, 2);
                    int[] uniform_lookup = new int[256]{
                             0, 1, 2, 3, 4, 58, 5, 6, 7, 58, 58, 58, 8, 58, 9, 10,
                            11, 58, 58, 58, 58, 58, 58, 58, 12, 58, 58, 58, 13, 58, 14, 15,
                            16, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58,
                            17, 58, 58, 58, 58, 58, 58, 58, 18, 58, 58, 58, 19, 58, 20, 21,
                            22, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58,
                            58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58,
                            23, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58,
                            24, 58, 58, 58, 58, 58, 58, 58, 25, 58, 58, 58, 26, 58, 27, 28,
                            29, 30, 58, 31, 58, 58, 58, 32, 58, 58, 58, 58, 58, 58, 58, 33,
                            58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 34,
                            58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58,
                            58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 35,
                            36, 37, 58, 38, 58, 58, 58, 39, 58, 58, 58, 58, 58, 58, 58, 40,
                            58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 58, 41,
                            42, 43, 58, 44, 58, 58, 58, 45, 58, 58, 58, 58, 58, 58, 58, 46,
                            47, 48, 58, 49, 58, 58, 58, 50, 51, 52, 58, 53, 54, 55, 56, 57
                         };
                    vrednost_pixlov_uniformni[uniform_lookup[bin_v_int]]++;
                    lbn.Data[i, j, 0] = (byte)uniform_lookup[bin_v_int];
                }
            }
            pictureBox3.Image = lbn.ToBitmap();
        }// end of LBPuniform

        private void LBPtransition()
        {
            int i;
            int j;
            int x;
            int y;
            int[,] maska = new int[3, 3];

            int[,] maska_primerjava = new int[3, 3];

            //int[] vrednosti_pixlov = new int[256];

            string bin_vrednost;
            int bin_v_int;

            imgSiva = My_ImageRecieve.Convert<Gray, Byte>();

            lbn = new Image<Gray, byte>(imgSiva.Width, imgSiva.Height);
            //gremo čez vse piksle slike
            for (i = 0; i < imgSiva.Height; i++)
            {
                for (j = 0; j < imgSiva.Width; j++)
                {

                    //dodajanje vrednosti v masko
                    for (x = 0; x < 3; x++)
                    {
                        for (y = 0; y < 3; y++)
                        {
                            //maska[0,0]
                            if (x == 0 && y == 0 && (i - 1 < 0 || j - 1 < 0))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i - 1, j - 1, 0];
                            }
                            //maska[0,1]
                            if (x == 0 && y == 1 && i - 1 < 0)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 1)
                            {

                                maska[x, y] = (int)imgSiva.Data[i - 1, j, 0];
                            }
                            //maska[0,2]
                            if (x == 0 && y == 2 && (i - 1 < 0 || j + 1 >= imgSiva.Width))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 0 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i - 1, j + 1, 0];
                            }
                            //maska[1,0]
                            if (x == 1 && y == 0 && j - 1 < 0)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 1 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j - 1, 0];
                            }
                            //maska[1,1]
                            if (x == 1 && y == 1)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j, 0];
                            }
                            //maska[1,2]
                            if (x == 1 && y == 2 && j + 1 >= imgSiva.Width)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 1 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i, j + 1, 0];
                            }
                            //maska[2,0]
                            if (x == 2 && y == 0 && (i + 1 >= imgSiva.Height || j - 1 < 0))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 0)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j - 1, 0];
                            }
                            //maska[2,1]
                            if (x == 2 && y == 1 && i + 1 >= imgSiva.Height)
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 1)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j, 0];
                            }

                            //maska[2,2]
                            if (x == 2 && y == 2 && (i + 1 >= imgSiva.Height || j + 1 >= imgSiva.Width))
                            {
                                maska[x, y] = 0;
                            }
                            else if (x == 2 && y == 2)
                            {
                                maska[x, y] = (int)imgSiva.Data[i + 1, j + 1, 0];
                            }

                        }
                    }

                    // primerjanje vrednosti v maski
                    /**            transition            **/
                    int h;
                    int v;
                    //uppermost horizontal 00|01|02
                    h = 0;
                    for (v = 0; v < 2; v++)//do dva ker preveri prvega z drugim in drugega z tretjim in konec
                    {
                        if (maska[h, v] > maska[h, v + 1])
                        {
                            maska_primerjava[h, v] = 1;
                        }
                        else
                            maska_primerjava[h, v] = 0;
                    }
                    h = 0;
                    v = 0;
                    //rightmost vertical 02|12|22 continuing from |02
                    v = 2;
                    for (h = 0; h < 2; h++)//do dva ker preveri prvega z drugim in drugega z tretjim in konec
                    {
                        if (maska[h, v] > maska[h + 1, v])
                        {
                            maska_primerjava[h, v] = 1;
                        }
                        else
                            maska_primerjava[h, v] = 0;
                    }
                    h = 0;
                    v = 0;
                    //bottom horizontal 20|21|22 in reverse order continuing from |22
                    h = 2;
                    for (v = 2; v > 0; v--)//do dva ker preveri prvega z drugim in drugega z tretjim in konec
                    {
                        if (maska[h, v] > maska[h, v - 1])
                        {
                            maska_primerjava[h, v] = 1;
                        }
                        else
                            maska_primerjava[h, v] = 0;
                    }
                    h = 0;
                    v = 0;
                    //leftmost vertical 00|10|20 continuing from 20| again in reverse from bottom up
                    v = 0;
                    for (h = 2; h > 0; h--)//do dva ker preveri prvega z drugim in drugega z tretjim in konec
                    {
                        if (maska[h, v] > maska[h - 1, v])
                        {
                            maska_primerjava[h, v] = 1;
                        }
                        else
                            maska_primerjava[h, v] = 0;
                    }
                    h = 0;
                    v = 0;
                    /**          transition end          **/
                    //pretvorba v binarno stivilo
                    //zacnemo z sosedom na poziciji maska[0,0] in nadaljujemo v smeri urinega kazalca po maski
                    bin_vrednost = maska_primerjava[0, 0].ToString() + maska_primerjava[0, 1].ToString() + maska_primerjava[0, 2].ToString() + maska_primerjava[1, 2].ToString() + maska_primerjava[2, 2].ToString() + maska_primerjava[2, 1].ToString() + maska_primerjava[2, 0].ToString() + maska_primerjava[1, 0].ToString();

                    //polje pojavitve vrednosti
                    bin_v_int = Convert.ToInt32(bin_vrednost, 2);
                    //vnesemo klko krat se kera vrednost pojavi
                    vrednosti_pixlov[bin_v_int]++;
                    //nastavimo vrednost piksla v novi sliki
                    lbn.Data[i, j, 0] = (byte)bin_v_int;

                }
            }
            pictureBox4.Image = lbn.ToBitmap();
        }// end of LBPtransition

        private void button2_Click(object sender, EventArgs e)
        {
            LBPbasic();
            insertMe();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LBPuniform();
            insertMe();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LBPtransition();
            insertMe();
        }
    }
}
